const request = require('supertest');
const server = require('../../backend/server');

describe('Weather API', () => {
  afterAll(async () => {
    await server.close();
  });

  describe('GET /api/weather', () => {
    it('should return weather data with correct structure', async () => {
      const response = await request(server)
        .get('/api/weather')
        .expect(200);

      expect(response.body).toHaveProperty('weather');
      expect(response.body).toHaveProperty('timestamp');
      expect(response.body.weather).toBe("Today's weather: Sunny and 72°F - Perfect for farm work!");
      expect(response.body.timestamp).toBe("2025-07-22T10:30:00Z");
    });

    it('should return JSON content type', async () => {
      const response = await request(server)
        .get('/api/weather')
        .expect(200)
        .expect('Content-Type', /json/);
    });
  });

  describe('GET /api/health', () => {
    it('should return health status', async () => {
      const response = await request(server)
        .get('/api/health')
        .expect(200);

      expect(response.body).toHaveProperty('status', 'healthy');
      expect(response.body).toHaveProperty('timestamp');
    });
  });

  describe('Error handling', () => {
    it('should handle invalid routes', async () => {
      await request(server)
        .get('/api/nonexistent')
        .expect(200); // Returns index.html due to catch-all route
    });
  });
});