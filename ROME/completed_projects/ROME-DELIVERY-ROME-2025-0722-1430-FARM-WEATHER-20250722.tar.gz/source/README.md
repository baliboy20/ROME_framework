# Farm Weather App

Simple weather application for farm employees - displays current weather conditions with a single button click.

## Quick Start

```bash
# Install dependencies
cd backend && npm install

# Start development server
npm run dev

# Start production server
npm start
```

## Project Structure

```
PROJECT/SOURCE/
├── frontend/
│   ├── index.html          # Main HTML file
│   ├── styles.css          # CSS styling
│   ├── script.js           # JavaScript functionality
│   └── assets/             # Static assets
├── backend/
│   ├── server.js           # Express server
│   ├── routes/             # API routes
│   ├── middleware/         # Custom middleware
│   └── package.json        # Backend dependencies
├── tests/
│   ├── backend/            # Backend tests
│   └── frontend/           # Frontend tests
├── .gitignore              # Git ignore rules
├── README.md               # This file
└── package.json            # Root package.json
```

## Ports

- Development: 3301 (backend serves frontend)
- Frontend Dev Server: 3302 (if needed)
- Production: 8094

## API Endpoints

- `GET /api/weather` - Returns current weather data
- `GET /api/health` - Health check endpoint
- `GET /*` - Serves frontend static files

## Deployment

```bash
# Development
npm run deploy:dev

# Production
npm run deploy:prod
```

Built by DevOps Robot (Luc) following ROME methodology.