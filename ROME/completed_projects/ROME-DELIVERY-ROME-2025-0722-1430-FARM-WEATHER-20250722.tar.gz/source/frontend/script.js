document.addEventListener('DOMContentLoaded', function() {
    const weatherBtn = document.getElementById('weather-btn');
    const weatherDisplay = document.getElementById('weather-display');
    const loading = document.getElementById('loading');
    const weatherInfo = document.getElementById('weather-info');
    const error = document.getElementById('error');
    
    weatherBtn.addEventListener('click', getWeather);
    
    async function getWeather() {
        try {
            showLoading();
            
            const response = await fetch('http://localhost:3301/api/weather');
            
            if (!response.ok) {
                throw new Error(`HTTP error! status: ${response.status}`);
            }
            
            const data = await response.json();
            displayWeather(data);
            
        } catch (err) {
            showError('Failed to get weather data. Please try again.');
            console.error('Weather fetch error:', err);
        }
    }
    
    function showLoading() {
        weatherDisplay.classList.remove('hidden');
        loading.style.display = 'block';
        weatherInfo.style.display = 'none';
        error.style.display = 'none';
        weatherInfo.innerHTML = '';
        error.innerHTML = '';
    }
    
    function displayWeather(data) {
        loading.style.display = 'none';
        weatherInfo.style.display = 'block';
        error.style.display = 'none';
        
        const weatherIcon = getWeatherIcon(data.weather);
        
        weatherInfo.innerHTML = `
            <div class="weather-header">
                <span class="weather-icon">${weatherIcon}</span>
                <h3>Farm Weather Update</h3>
            </div>
            <div class="weather-details">
                <p class="weather-message"><strong>🌾 ${data.weather}</strong></p>
                <p><small>🕐 Updated: ${new Date(data.timestamp).toLocaleString()}</small></p>
            </div>
        `;
    }
    
    function getWeatherIcon(condition) {
        const conditionLower = condition.toLowerCase();
        if (conditionLower.includes('sunny') || conditionLower.includes('clear')) {
            return '☀️';
        } else if (conditionLower.includes('cloudy')) {
            return '☁️';
        } else if (conditionLower.includes('rain')) {
            return '🌧️';
        } else if (conditionLower.includes('storm')) {
            return '⛈️';
        } else if (conditionLower.includes('snow')) {
            return '❄️';
        } else if (conditionLower.includes('fog')) {
            return '🌫️';
        } else {
            return '🌤️';
        }
    }
    
    function showError(message) {
        loading.style.display = 'none';
        weatherInfo.style.display = 'none';
        error.style.display = 'block';
        error.textContent = message;
    }
});