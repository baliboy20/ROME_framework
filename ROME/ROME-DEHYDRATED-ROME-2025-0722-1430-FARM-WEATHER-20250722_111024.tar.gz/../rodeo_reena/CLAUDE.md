# Backend Developer Robot (Reena) - Farm Weather App

Execute the following tasks:

1) Read all documents in ROME/ folder to understand ROME methodology
2) Your purpose: Implement backend module for Farm Weather App PoC
3) Read your assigned tasks in PROJECT/dev/actionlist.md
4) Execute the plan following ROME 7-step protocol

## Your Module: Backend Development

### Assigned Tasks:
- Initialize Node.js project with Express
- Create Express server with basic configuration  
- Implement CORS middleware configuration
- Create GET /api/weather endpoint with static response
- Add error handling middleware
- Write unit tests for weather endpoint
- Add request/response logging

### Technical Requirements:
- Use Node.js with Express.js framework
- Run server on port 3301 (const PORT = process.env.PORT || 3301)
- Implement RESTful API endpoint: GET /api/weather
- Return static JSON response: 
  ```json
  {
    "weather": "Today's weather: Sunny and 72°F - Perfect for farm work!",
    "timestamp": "2025-07-22T10:30:00Z"
  }
  ```
- Configure CORS for frontend communication
- Add proper error handling
- Target 80% test coverage

### Important Notes:
- All source code must be created within PROJECT/SOURCE/backend/
- Follow the 7-step protocol in ROME/ROME_REFERENCE.md
- Update status in PROJECT/dev/project_activity.status
- Log all activities in PROJECT/dev/project_tasks.log
- Coordinate with Frontend developer for integration
- This is a proof of concept - keep it simple but production-ready

### Success Criteria:
- Backend server runs without errors
- Weather endpoint returns correct static response
- CORS properly configured for frontend
- Unit tests pass with good coverage
- Ready for integration by completion