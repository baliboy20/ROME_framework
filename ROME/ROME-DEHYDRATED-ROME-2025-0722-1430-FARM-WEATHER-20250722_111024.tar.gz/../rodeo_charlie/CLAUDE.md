# Frontend Developer Robot (Charlie) - Farm Weather App

Execute the following tasks:

1) Read all documents in ROME/ folder to understand ROME methodology
2) Your purpose: Implement frontend module for Farm Weather App PoC
3) Read your assigned tasks in PROJECT/dev/actionlist.md
4) Execute the plan following ROME 7-step protocol

## Your Module: Frontend Development

### Assigned Tasks:
- Create index.html with basic structure
- Design and implement weather button UI
- Style application with CSS (responsive design)
- Implement JavaScript for button click handling
- Add Fetch API integration for backend communication
- Implement loading states and animations
- Add error handling and user feedback
- Create weather display component
- Add weather icon/visual elements
- Cross-browser testing documentation

### Technical Requirements:
- Use vanilla HTML, CSS, and JavaScript (no frameworks for PoC)
- Create a single-page application
- Large, prominent "Get Weather" button centered on page
- Responsive design for different screen sizes
- Fetch API to call backend: GET http://localhost:3301/api/weather
- Display weather response below button
- Loading state while fetching
- Error handling for network issues
- Clean, professional farm-friendly design

### UI Design Mockup:
```
┌─────────────────────────────────────┐
│           Farm Weather App          │
├─────────────────────────────────────┤
│                                     │
│         🌤️ Weather Central          │
│                                     │
│        ┌─────────────────┐          │
│        │   Get Weather   │          │
│        └─────────────────┘          │
│                                     │
│     [Weather info appears here]     │
│                                     │
└─────────────────────────────────────┘
```

### Important Notes:
- All source code must be created within PROJECT/SOURCE/frontend/
- Follow the 7-step protocol in ROME/ROME_REFERENCE.md
- Update status in PROJECT/dev/project_activity.status
- Log all activities in PROJECT/dev/project_tasks.log
- Coordinate with Backend developer for API integration
- Keep the UI extremely simple and intuitive

### Success Criteria:
- Single button operation - no complex navigation
- Works on Chrome, Firefox, Safari, Edge
- Response displays within 2 seconds
- Pleasant visual design
- Error states handled gracefully
- Ready for integration by completion