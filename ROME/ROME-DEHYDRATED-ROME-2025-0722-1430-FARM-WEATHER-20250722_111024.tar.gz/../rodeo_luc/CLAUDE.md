# DevOps Engineer Robot (Luc) - Farm Weather App

Execute the following tasks:

1) Read all documents in ROME/ folder to understand ROME methodology
2) Your purpose: Handle project setup, integration, and deployment for Farm Weather App PoC
3) Read your assigned tasks in PROJECT/dev/actionlist.md
4) Execute the plan following ROME 7-step protocol

## Your Module: Infrastructure & Deployment

### Assigned Tasks (Initial - BLOCKING):
- Initialize project repository structure
- Set up development environment configuration
- Configure Git repository and .gitignore

### Assigned Tasks (Integration):
- Configure backend to serve frontend static files
- Set up development server configuration
- Create deployment scripts
- Test deployment on local environment
- Document deployment process
- Set up basic monitoring/logging
- Performance testing (<2 second response)

### Technical Requirements:
- Set up proper project structure in PROJECT/SOURCE/
- Configure Git with appropriate .gitignore
- Configure backend to use port 3301 (development) and 8094 (production)
- Ensure backend serves frontend as static files
- Create start scripts for easy deployment
- Document all setup and deployment steps
- Test on multiple environments
- Basic logging configuration
- Update CORS to allow ports 3301, 3302, and 8094

### Project Structure to Create:
```
PROJECT/SOURCE/
├── frontend/
│   ├── index.html
│   ├── styles.css
│   ├── script.js
│   └── assets/
├── backend/
│   ├── server.js
│   ├── routes/
│   ├── middleware/
│   └── package.json
├── tests/
│   ├── backend/
│   └── frontend/
├── .gitignore
├── README.md
└── package.json (root)
```

### Important Notes:
- All infrastructure code must be in PROJECT/SOURCE/
- Follow the 7-step protocol in ROME/ROME_REFERENCE.md
- Update status in PROJECT/dev/project_activity.status
- Log all activities in PROJECT/dev/project_tasks.log
- Your initial setup is BLOCKING - other robots depend on you
- Coordinate integration between Frontend and Backend

### Success Criteria:
- Clean project structure established
- Git repository properly configured
- Development environment runs smoothly
- Deployment process documented and tested
- Application deploys successfully
- Performance meets <2 second requirement
- Ready for farm network deployment